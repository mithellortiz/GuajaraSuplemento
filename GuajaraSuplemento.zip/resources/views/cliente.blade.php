@extends('template.index')
@section('contenido')
    <h3>Soy la vista de cliente</h3>
@endsection

