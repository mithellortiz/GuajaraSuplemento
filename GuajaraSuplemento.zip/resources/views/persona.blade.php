@extends('template.index')
@section('contenido')
    <h3>Soy la vista de persona</h3>
@endsection

