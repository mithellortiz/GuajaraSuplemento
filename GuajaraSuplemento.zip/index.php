<?php
header('location: public');
?>