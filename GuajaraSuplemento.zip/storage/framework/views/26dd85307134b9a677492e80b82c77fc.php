
<?php $__env->startSection('titulo','Registrar Usuario'); ?>
<?php $__env->startSection('contenido'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
   <form action="<?php echo e(route('usuario.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <div class="row">
            <div class="col-md-3">
                <!-- Dentro do seu formulário, provavelmente dentro de uma tag <form>... -->
                <label for="nombre_persona">Nombre Persona</label>
                <input type="text" name="nombre_persona" value="<?php echo e(old('nombre_persona')); ?>" class="form-control" required>
            </div>
            <div class="col-md-3">
                <label for="apellido_persona">Apellido de Persona</label>
                <input type="text" name="apellido_persona" id="" class="form-control" required>
            </div>
            <div class="col-md-3">
                <label for="email">E-mail</label>
                <input type="text" name="email" id="" class="form-control" required>
            </div>
            <div class="col-md-3">
            <label for="password">Contraseña</label>
               <input type="text" name="password" id="" class="form-control" required>
            </div>
        </div>
        <!-- Comando para por o botao pra direita ->(style="display: flex; justify-content: flex-end;") -->
        <div class="row" style="display: flex; justify-content: flex-end;"  >
            <div class="col-md-3">
                <button type="submit" class="btn btn-success btn-block mt-3 pull-right">
                    <i class="fa fa-plus" ></i>
                    Registrar
                </button>
            </div>
        </div>
   </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GuajaraSuplemento\resources\views/admin/usuario/create.blade.php ENDPATH**/ ?>