
<?php $__env->startSection('titulo','Registrar Cliente'); ?>
<?php $__env->startSection('contenido'); ?>
   <form action="<?php echo e(route('cliente.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <div class="row">
            <div class="col-md-3">
                <input type="text" name="nit" id="" class="form-control" required autofocus>
            </div>
            <div class="col-md-3">
                <input type="text" name="tipocliente" id="" class="form-control" required>
            </div>
        </div>
        <!-- Comando para por o botao pra direita ->(style="display: flex; justify-content: flex-end;") -->
        <div class="row" style="display: flex; justify-content: flex-end;"  >
            <div class="col-md-3">
                <button type="submit" class="btn btn-success btn-block mt-3 pull-right">
                    <i class="fa fa-plus" ></i>
                    Registrar
                </button>
            </div>
        </div>
   </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GuajaraSuplemento\resources\views/admin/cliente/create.blade.php ENDPATH**/ ?>