<?php $__env->startSection('contenido'); ?>
    <h3>Soy la vista de persona</h3>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GuajaraSuplemento\resources\views/persona.blade.php ENDPATH**/ ?>