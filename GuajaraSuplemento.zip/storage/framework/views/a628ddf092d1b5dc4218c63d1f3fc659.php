<!-- invocando plantilla -->

<?php $__env->startSection('titulo','Lista de Usuario'); ?>
<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($usuario->getNombreFromPersona()); ?></td>
                            <td><?php echo e($usuario->getApellidoFromPersona()); ?></td>
                            <td><?php echo e($usuario->email); ?></td>
                            <td><?php echo e($usuario->password); ?></td>
                            <td>********</td>
                            <td><?php echo e(str_repeat('*', strlen($usuario->password))); ?></td>
                            <td>
                                <a href="<?php echo e(route('usuario.edit', $usuario->id)); ?>"
                                    class="btn btn-small btn-primary">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('usuario.destroy', $usuario->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-small" onclick="return confirm('Esta seguro de eliminar el dato?')">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5">No hay usuarios registrados</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="row" style="font-size: 12px; height: 16px; padding: 0; line-height: 16px; text-align: center;">
        <div class="col-md-12">
            <?php echo e($usuarios->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GuajaraSuplemento\resources\views/admin/usuario/index.blade.php ENDPATH**/ ?>