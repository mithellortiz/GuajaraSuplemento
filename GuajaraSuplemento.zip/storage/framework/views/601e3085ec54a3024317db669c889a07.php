<!-- invocando plantilla -->


<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('persona.update', $persona->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-3">
                        <input type="text" name="nombre" id="nombre" 
                        class="form-control" placeholder="Nombre"
                        value="<?php echo e($persona->nombre); ?>" required>
                    </div>
                    <div class="col-md-3">
                         <input type="text" name="apellido" id="apellido" 
                          class="form-control" placeholder="Apellido"
                          value="<?php echo e($persona->apellido); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="celular" id="celular" 
                         class="form-control" placeholder="Celular"
                         value="<?php echo e($persona->celular); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="direccion" id="direccion" 
                         class="form-control" placeholder="Direccion"
                         value="<?php echo e($persona->direccion); ?>" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-9">
                        <div class="col-md-3">
                            <input type="submit" value="Editar" 
                            style="padding-left: 100px; padding-right: 100px; width: 700px;" class="btn btn-success mt-4 pull-right btn-block">
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GuajaraSuplemento\resources\views/admin/persona/edit.blade.php ENDPATH**/ ?>