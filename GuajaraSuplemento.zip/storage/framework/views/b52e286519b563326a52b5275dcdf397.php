<!--  -->

<?php $__env->startSection('contenido'); ?>
<!-- Mudar para class="row" -->
    <div class="row">
        <div class="col-md-12">
            <!-- <h1>Tipos de Usuários</h1> -->
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Descrição</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($tipo->id); ?></td>
                        <td><a href="<?php echo e(route('tipousuario.show', $tipo->id)); ?>"><?php echo e($tipo->nombre_tipo); ?></a></td>
                        <td>
                            <a href="<?php echo e(route('tipousuario.create')); ?>" 
                                class="btn btn-primary mb-2">
                             <i class="fa fa-plus-circle"></i>
                            </a>
                            <!-- Aqui você pode adicionar botões para editar, deletar etc. -->
                            <a href="<?php echo e(route('tipousuario.edit', $tipo->id)); ?>" 
                                class="btn btn-warning mb-2">
                                <i class="fa fa-edit"></i>
                            </a>
                            <!-- Adicione outras ações conforme necessário -->
                            <a href="<?php echo e(route('tipousuario.destroy', $tipo->id)); ?>"
                                onclick="return confirm('Esta seguro de eliminar el dato?')"
                                class="btn btn-danger btn-small mb-2">
                                <i class="fa fa-trash"></i>
                            </a>
                        </td> 
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GuajaraSuplemento\resources\views/admin/tipousuario/index.blade.php ENDPATH**/ ?>